---
layout: page
title: Research
permalink: /research/
---
  
##Some cool research I am working on!
1. Going to Australia
   * studying  
  
### More Information
  
  A place to include any other types of information that you'd like to include about yourself. 

### Contact me

<!---
[mlfurman@ncsu.edu](mailto:email@domain.com)
-->

