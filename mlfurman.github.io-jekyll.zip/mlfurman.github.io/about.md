---
layout: page
title: About
permalink: /about/
---

I am an undergrad at North Carolina State University, majoring in statistics and applied math. I have worked on multiple research projects, which I would like to share here. Please feel free to explore and contact me with any questions!

### More Information

A place to include any other types of information that you'd like to include about yourself. 

### Contact me

<!---
[mlfurman@ncsu.edu](mailto:email@domain.com)
-->
