---
title: "Dr. Jekyll and Mr. Markdown"
output: word_document
layout: post
---
This is my first (and probably last) blog post.
